function display(id) {
    let element = document.getElementById(id);
    if (element.style.display === "none" || element.style.display === "") {
        element.style.display = "block"; // Show
    } else {
        element.style.display = "none"; // Hide
    }
}